#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


DEFAULT_BANNED = [
    "output/",
    "docs/",
    "scripts/",
    "openspec/",
    "data/",
    "sql/",
    "src/",
    "tests/",
    "openspec",
    "uv run",
    "tier_",
    "semantic_boundary",
    "forbidden_implications",
]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Manuscript lint gate: prevent internal-path/audit leakage.")
    p.add_argument(
        "--manuscript",
        default=str(ROOT / "docs" / "manuscript" / "manuscript.md"),
        help="Path to submission manuscript markdown.",
    )
    p.add_argument(
        "--claims",
        default=str(ROOT / "docs" / "CLAIMS.tsv"),
        help="Claims TSV to extract claim IDs that must not appear in submission manuscript.",
    )
    p.add_argument(
        "--out",
        default=str(ROOT / "docs" / "MANUSCRIPT_LINT_REPORT.md"),
        help="Path to write lint report markdown.",
    )
    return p.parse_args()


def _load_claim_ids(path: Path) -> list[str]:
    if not path.exists():
        return []
    lines = path.read_text(encoding="utf-8").splitlines()
    if not lines:
        return []
    header = lines[0].split("\t")
    try:
        idx = header.index("claim_id")
    except ValueError:
        return []
    ids: list[str] = []
    for ln in lines[1:]:
        if not ln.strip():
            continue
        parts = ln.split("\t")
        if idx < len(parts) and parts[idx].strip():
            ids.append(parts[idx].strip())
    return sorted(set(ids))


def main() -> None:
    args = parse_args()
    manuscript_path = Path(args.manuscript)
    claims_path = Path(args.claims)
    out_path = Path(args.out)

    text = manuscript_path.read_text(encoding="utf-8") if manuscript_path.exists() else ""
    banned = list(DEFAULT_BANNED)

    claim_ids = _load_claim_ids(claims_path)
    banned.extend(claim_ids)
    # Also ban the common prefix form (e.g., "C1_") to catch partial leakage.
    banned.extend(sorted({cid.split("_", 1)[0] + "_" for cid in claim_ids if "_" in cid}))

    hits: dict[str, int] = {}
    for tok in banned:
        if not tok:
            continue
        n = text.count(tok)
        if n:
            hits[tok] = n

    ok = len(hits) == 0
    out_path.parent.mkdir(parents=True, exist_ok=True)
    lines: list[str] = []
    lines.append("# Manuscript Lint Report")
    lines.append("")
    lines.append(f"- Manuscript: `{manuscript_path}`")
    lines.append(f"- Status: {'PASS' if ok else 'FAIL'}")
    lines.append("")
    lines.append("## Banned Tokens/Patterns")
    for tok in banned:
        lines.append(f"- `{tok}`")
    lines.append("")
    lines.append("## Hits")
    if ok:
        lines.append("- None")
    else:
        for tok, n in sorted(hits.items(), key=lambda x: (-x[1], x[0])):
            lines.append(f"- `{tok}`: {n}")
    lines.append("")

    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    raise SystemExit(0 if ok else 2)


if __name__ == "__main__":
    main()

